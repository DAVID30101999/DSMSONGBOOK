const songs = [
    {
        title: "உயிரே என் உயிரே",
        lyrics: `உயிரே என் உயிரே என் உயிரே உம்மை துதிப்பேன்-2
1. என் உயிரோடு கலந்தவரே என் நினைவெல்லாம் நிறைந்தவரே என் பேச்செல்லாம் நீர்தானே என் மூச்செல்லாம் நீர்தானே
2. நீரில்லாமல் வாழ்வேது நீரில்லாமல் வழியேது நீரில்லாமல் துணையில்லையே நீரில்லாமல் பெலன் இல்லையே
3. உம்மைப் போல யாருமில்லை உம் அன்பை போல எதுவுமில்லை என் உறவும் நீர்தானே என் சொந்தமும் நீர்தானே`
    },
    // Add more songs here
];

let currentSongIndex = null; // Track the current song for favorites
let favorites = []; // Array to store favorite songs

function displaySongs() {
    const songList = document.getElementById('song-list');
    songList.innerHTML = ''; // Clear existing songs
    songs.forEach((song, index) => {
        const songDiv = document.createElement('div');
        songDiv.className = 'song';

        const number = document.createElement('div');
        number.className = 'song-number';
        number.textContent = index + 1; // Display song number

        const title = document.createElement('div');
        title.className = 'song-title';
        title.textContent = song.title;
        title.onclick = () => showPreview(index); // Show preview when title is clicked

        songDiv.appendChild(number);
        songDiv.appendChild(title);
        songList.appendChild(songDiv);
    });
}

function toggleFavorite(index) {
    const favoriteIndex = favorites.indexOf(index);
    if (favoriteIndex === -1) {
        favorites.push(index); // Add to favorites
    } else {
        favorites.splice(favoriteIndex, 1); // Remove from favorites
    }
    displayFavorites(); // Refresh favorites display
}

function showPreview(index) {
    currentSongIndex = index; // Set current song index
    const songPreview = document.getElementById('song-preview');
    const songTitle = document.getElementById('song-title');
    const songLyrics = document.getElementById('song-lyrics');
    
    songTitle.textContent = songs[index].title;
    songLyrics.textContent = songs[index].lyrics;
    
    songPreview.style.display = 'block';  // Show preview
    document.getElementById('song-list').style.display = 'none'; // Hide song list
    updateFavoriteButton();
}

function hidePreview() {
    document.getElementById('song-preview').style.display = 'none'; // Hide preview
    document.getElementById('song-list').style.display = 'block'; // Show song list again
}

function updateFavoriteButton() {
    const button = document.getElementById('favorite-button');
    if (currentSongIndex !== null) {
        button.textContent = favorites.includes(currentSongIndex) ? 'Remove from Favorites' : 'Add to Favorites';
    }
}

function displayFavorites() {
    const favoritesList = document.getElementById('favorites-list');
    favoritesList.innerHTML = ''; // Clear existing favorites
    favorites.forEach(index => {
        const favoriteDiv = document.createElement('div');
        favoriteDiv.className = 'favorite-song';
        favoriteDiv.textContent = songs[index].title;
        favoriteDiv.onclick = () => showPreview(index); // Show preview on click
        favoritesList.appendChild(favoriteDiv);
    });
}

// Call displaySongs initially
document.addEventListener('DOMContentLoaded', displaySongs);
const songs = [
    {
        title: "Song One",
        lyrics: "These are the lyrics for Song One."
    },
    {
        title: "Song Two",
        lyrics: "These are the lyrics for Song Two."
    },
    {
        title: "Song Three",
        lyrics: "These are the lyrics for Song Three."
    },
    // Add more songs as needed
];

let currentSongIndex = null;
let favorites = [];

function displaySongs() {
    const songList = document.getElementById('song-list');
    songList.innerHTML = '';
    songs.forEach((song, index) => {
        const songDiv = document.createElement('div');
        songDiv.className = 'song';
        songDiv.textContent = song.title;
        songDiv.onclick = () => showPreview(index);
        songList.appendChild(songDiv);
    });
}

function showPreview(index) {
    currentSongIndex = index;
    const songPreview = document.getElementById('song-preview');
    const songTitle = document.getElementById('song-title');
    const songLyrics = document.getElementById('song-lyrics');
    
    songTitle.textContent = songs[index].title;
    songLyrics.textContent = songs[index].lyrics;
    
    songPreview.style.display = 'block';
    document.getElementById('song-list').style.display = 'none';
    updateFavoriteButton();
}

function goBack() {
    document.getElementById('song-preview').style.display = 'none';
    document.getElementById('song-list').style.display = 'block';
}

function toggleFavorite() {
    if (currentSongIndex === null) return;
    const index = favorites.indexOf(currentSongIndex);
    if (index === -1) {
        favorites.push(currentSongIndex);
    } else {
        favorites.splice(index, 1);
    }
    updateFavoritesList();
    updateFavoriteButton();
}

function updateFavoriteButton() {
    const button = document.getElementById('favorite-button');
    button.textContent = favorites.includes(currentSongIndex) ? '★' : '☆';
}

function updateFavoritesList() {
    const favoritesList = document.getElementById('favorites-list');
    favoritesList.innerHTML = '';
    favorites.forEach(index => {
        const favoriteDiv = document.createElement('div');
        favoriteDiv.className = 'song';
        favoriteDiv.textContent = songs[index].title;
        favoriteDiv.onclick = () => showPreview(index);
        favoritesList.appendChild(favoriteDiv);
    });
}

function filterSongs() {
    const query = document.getElementById('search-input').value.toLowerCase();
    const songElements = document.querySelectorAll('.song');
    songElements.forEach((element, index) => {
        const title = songs[index].title.toLowerCase();
        element.style.display = title.includes(query) ? 'block' : 'none';
    });
}

// Initialize song list on page load
document.addEventListener('DOMContentLoaded', displaySongs);
// Add touch feedback for song items
document.querySelectorAll('.song').forEach(item => {
    item.addEventListener('touchstart', () => {
        item.classList.add('active');
    });
    item.addEventListener('touchend', () => {
        item.classList.remove('active');
    });
});
function showPreview(index) {
    currentSongIndex = index; // Set current song index
    const songPreview = document.getElementById('song-preview');
    const songTitle = document.getElementById('song-title');
    const songLyrics = document.getElementById('song-lyrics');

    // Get the song number (index + 1)
    const songNumber = index + 1;

    // Set the title with the song number
    songTitle.textContent = `Song ${songNumber}: ${songs[index].title}`; // Update title with song number
    songLyrics.textContent = songs[index].lyrics;

    songPreview.style.display = 'block';  // Show preview
    document.getElementById('song-list').style.display = 'none'; // Hide song list
    updateFavoriteButton();
}
document.addEventListener('DOMContentLoaded', () => {
    // Show the welcome page initially
    document.getElementById('welcome-page').style.display = 'flex';

    // Add event listener to start button
    document.getElementById('start-button').onclick = () => {
        document.getElementById('welcome-page').style.display = 'none'; // Hide welcome page
        displaySongs(); // Call function to display songs
    };
});